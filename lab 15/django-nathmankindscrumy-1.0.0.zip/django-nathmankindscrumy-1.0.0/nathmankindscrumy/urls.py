from django.urls import include, path
from . import views

urlpatterns = [
    path('', views.index, name='index'),

    #path for goal_id
    path('movegoal/<int:goal_id>', views.move_goal, name='movegoal'),

    #path for add goal
    #path('addgoal', views.add_goal, name="add goal"),

    #path for home
    path('home', views.home, name='home')
]
