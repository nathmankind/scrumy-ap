from django.template import loader
from django.http import HttpResponse
from .models import GoalStatus
from .models import ScrumyGoals
from .models import User
from random import randint
# Create your views here.


def index(request):
    goals = ScrumyGoals.objects.all()
    template = loader.get_template("nathmankindscrumy/home.html")
    context = {'goals': goals}
    return HttpResponse(template.render(context, request))
    # output = ScrumyGoals.objects.filter(goal_name="Learn Django")


def move_goal(request, goal_id):
    return HttpResponse("You are looking at goal %s." % goal_id)


# def add_goal(request):
#     week = GoalStatus.objects.get(id=8)
#     user = User.objects.get(id=4)
#     new_goal = ScrumyGoals.objects.create(goal_name="Keep Learning Django",
#                                           goal_id=randint(1000, 9999),
#                                           created_by="Louis", moved_by="Louis",
#                                           owner="Louis", goal_status=week,
#                                           user=user)
#     new_goal.save()
#     goals = ScrumyGoals.objects.all()
#     output = ','.join([x.goal_name for x in goals])
#     template = loader.get_template("index/home.html")
#     context = {'goals': goals}
#     return HttpResponse(output)
# template.render(context,request)

def home(request):
    return HttpResponse(ScrumyGoals.objects.filter(goal_name="Learn Django"))

