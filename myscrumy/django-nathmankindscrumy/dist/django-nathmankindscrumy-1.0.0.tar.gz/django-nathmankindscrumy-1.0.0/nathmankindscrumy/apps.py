from django.apps import AppConfig


class NathmankindscrumyConfig(AppConfig):
    name = 'nathmankindscrumy'
