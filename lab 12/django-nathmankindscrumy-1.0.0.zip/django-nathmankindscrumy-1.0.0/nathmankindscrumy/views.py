from django.shortcuts import render
from django.http import HttpResponse
from .models import ScrumyGoals
# Create your views here.

def index(request):
    output = ScrumyGoals.objects.filter(goal_name="Learn Django")
    return HttpResponse(output)

def move_goal(request, goal_id):
    return HttpResponse("You are looking at goal %s." % goal_id)

