from django.urls import include, path
from . import views

urlpatterns = [
    path('', views.index, name='index'),

    #path for goal_id
    path('movegoal/<int:goal_id>', views.move_goal, name='movegoal')
]
