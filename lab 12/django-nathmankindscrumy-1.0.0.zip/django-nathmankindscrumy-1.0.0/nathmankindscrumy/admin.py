from django.contrib import admin

from .models import GoalStatus, ScrumyGoals, ScrumyHistory

# Register your models here.

admin.site.register(GoalStatus)
admin.site.register(ScrumyGoals)
admin.site.register(ScrumyHistory)

# goals = ScrumyGoals(goal_name="Learn Django", goal_id=1, created_by="Louis", moved_by="Louis", owner="Louis", goal_
